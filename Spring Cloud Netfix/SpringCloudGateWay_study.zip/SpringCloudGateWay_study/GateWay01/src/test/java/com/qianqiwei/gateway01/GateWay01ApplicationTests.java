package com.qianqiwei.gateway01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GateWay01ApplicationTests {

    @Test
    void contextLoads() {
    }

}
