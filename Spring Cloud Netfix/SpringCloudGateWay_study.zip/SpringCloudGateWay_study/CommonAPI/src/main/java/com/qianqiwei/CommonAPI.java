package com.qianqiwei;

public interface CommonAPI {
    public String index();
}
