package com.qianqiwei.consumer02;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Consumer02ApplicationTests {

    @Test
    void contextLoads() {
    }

}
