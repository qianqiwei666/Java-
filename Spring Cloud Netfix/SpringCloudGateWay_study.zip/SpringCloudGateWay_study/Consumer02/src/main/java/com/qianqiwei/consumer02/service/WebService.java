package com.qianqiwei.consumer02.service;

import com.qianqiwei.CommonAPI;
import org.apache.dubbo.config.annotation.DubboReference;
import org.springframework.stereotype.Service;

@Service
public class WebService {
    @DubboReference(version = "1.0.0",group = "provider")
    public CommonAPI commonAPI;

    public String index(){
        return "consumer02:"+commonAPI.index();
    }

}
