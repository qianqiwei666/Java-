package com.qianqiwei.consumer02.controller;


import com.qianqiwei.consumer02.service.WebService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class WebController {
    @Autowired
    private WebService webService;
    @GetMapping("/index")
    public String index(){
        return webService.index();
    }
}
