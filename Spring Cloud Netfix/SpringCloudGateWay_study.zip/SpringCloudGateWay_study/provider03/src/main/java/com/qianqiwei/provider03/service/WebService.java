package com.qianqiwei.provider03.service;

import com.qianqiwei.CommonAPI;
import org.apache.dubbo.config.annotation.DubboService;

@DubboService(interfaceClass = CommonAPI.class)
public class WebService implements CommonAPI {

    @Override
    public String index() {
        return "我是provider03";
    }
}
