package com.qianqiwei.consumer01.controller;

import com.qianqiwei.consumer01.service.WebService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class WebController {
    @Autowired
    private WebService webService;
    @GetMapping("/index")
    public String index(){
        return webService.index();
    }
}
