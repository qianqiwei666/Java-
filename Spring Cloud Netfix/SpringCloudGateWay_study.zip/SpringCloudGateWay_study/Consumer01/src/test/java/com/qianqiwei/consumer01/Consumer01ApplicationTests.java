package com.qianqiwei.consumer01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Consumer01ApplicationTests {

    @Test
    void contextLoads() {
    }

}
