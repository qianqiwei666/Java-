package com.qianqiwei.config;

import io.redisearch.client.Client;
import org.springframework.stereotype.Component;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;

/**
 * @author : 钱琪炜
 * @date : 2022/7/2
 */
public class RedisSearchClientBuilder {

    //Jedis客户端
    private Jedis jedis;
    //索引名称
    private String indexName;

    //构建Jedis
    public RedisSearchClientBuilder buildJedis(Jedis jedis){
        this.jedis=jedis;
        return this;
    }
    //构造索引名称
    public RedisSearchClientBuilder buildIndexName(String indexName){
        this.indexName=indexName;
        return this;
    }
    //构造完成
    public Client build(){
        Client client=new Client(this.indexName,jedis);
        return client;
    }

}
