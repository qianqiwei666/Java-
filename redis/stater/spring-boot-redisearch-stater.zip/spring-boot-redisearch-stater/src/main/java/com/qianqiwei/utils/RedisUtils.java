package com.qianqiwei.utils;

import com.alibaba.fastjson.JSON;

import java.util.Map;

/**
 * @author : 钱琪炜
 * @date : 2022/7/2
 */

public class RedisUtils {
    public static<T> Map<String,Object> convertObj(T obj){
        return JSON.parseObject(JSON.toJSONBytes(obj),Map.class);
    }
}
