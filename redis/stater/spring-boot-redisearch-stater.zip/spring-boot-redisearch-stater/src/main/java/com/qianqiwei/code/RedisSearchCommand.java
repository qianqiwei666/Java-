package com.qianqiwei.code;

import com.qianqiwei.config.RedisSearchClientBuilder;
import com.qianqiwei.utils.RedisUtils;
import io.redisearch.Document;
import io.redisearch.Query;
import io.redisearch.Schema;
import io.redisearch.client.Client;
import io.redisearch.client.IndexDefinition;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import redis.clients.jedis.Jedis;

import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * @author : 钱琪炜
 * @date : 2022/7/2
 */
@Component
public class RedisSearchCommand {
    @Autowired
    private RedisSearchClientBuilder redisSearchClientBuilder;


    /**
     * 创建索引
     * @param indexName 索引的名称
     * @param indexDefinition 索引条件
     * @param schema  需要被索引的属性
     * @return
     */
    //创建索引
    public boolean createIndex(String indexName, IndexDefinition indexDefinition, Schema schema){
        Client client = redisSearchClientBuilder.buildIndexName(indexName).build();
        client.createIndex(schema, Client.IndexOptions.defaultOptions().setDefinition(indexDefinition));
        client.close();
        return true;
    }

    /**
     * 删除索引
     * @param indexName 索引名称
     * @return
     */
    //删除索引
    public boolean dropIndex(String indexName){
        Client client = redisSearchClientBuilder.buildIndexName(indexName).build();
        boolean isDrop = client.dropIndex();
        client.close();
        return isDrop;
    }

    /**
     * 创建索引文档(基于对象)
     * @param indexName 索引名称
     * @param objList  对象集合
     * @param <T>
     */
    public<T> void createIndexDocumentByObj(String indexName, List<T> objList){
        Client client = redisSearchClientBuilder.buildIndexName(indexName).build();
        objList.forEach(item->{
            client.addDocument(UUID.randomUUID().toString().replaceAll("-",""), RedisUtils.convertObj(item));
        });
        client.close();
    }

    /**
     * 创建索引(基于map)
     * @param indexName 索引名称
     * @param map Map
     */

    public void createIndexDocumentByMap(String indexName, Map<String,Object> map){
        Client client = redisSearchClientBuilder.buildIndexName(indexName).build();
        client.addDocument(UUID.randomUUID().toString().replaceAll("-",""),map);
        client.close();
    }

    /**
     * 批量创建索引(基于map)
     * @param indexName 索引名称
     * @param maps  map集合
     */

    public void createIndexDocumentByMapBath(String indexName, List<Map<String,Object>> maps){
        Client client = redisSearchClientBuilder.buildIndexName(indexName).build();
        maps.forEach(item->{
            client.addDocument(UUID.randomUUID().toString().replaceAll("-",""),item);
        });
        client.close();
    }

    /**
     * 查询索引
     * @param indexName 索引名称
     * @param query  查询所需的条件
     * @return
     */


    public List<Document> query(String indexName, Query query){
        Client client = redisSearchClientBuilder.buildIndexName(indexName).build();
        List<Document> docs=client.search(query).docs;
        client.close();
        return docs;
    }



}
