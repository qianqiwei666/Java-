package com.qianqiwei.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * @author : 钱琪炜
 * @date : 2022/7/2
 */

@ConfigurationProperties(prefix = "com.qianqiwei.redisearch")
public class RedisSearchProperties {
    private String address;
    private int port;

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public RedisSearchProperties() {
    }

    public RedisSearchProperties(String address, int port) {
        this.address = address;
        this.port = port;
    }
}
