package com.qianqiwei;

import com.qianqiwei.config.RedisSearchClientBuilder;
import com.qianqiwei.config.RedisSearchProperties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;

/**
 * @author : 钱琪炜
 * @date : 2022/7/2
 */
@Configuration
@EnableConfigurationProperties({RedisSearchProperties.class})
@ComponentScan(basePackages = {"com.qianqiwei"})
public class SpringStater {
    @Autowired
    private RedisSearchProperties redisSearchProperties;

    @Autowired
    //完成基本构造
    @Bean
    public RedisSearchClientBuilder redisSearchClientBuilder(Jedis jedis) {
        RedisSearchClientBuilder redisSearchClientBuilder = new RedisSearchClientBuilder();
        return redisSearchClientBuilder.buildJedis(jedis);
    }

    @Bean
    public Jedis jedis(){
        JedisPool jedisPool=new JedisPool(redisSearchProperties.getAddress(),redisSearchProperties.getPort());
        return jedisPool.getResource();
    }



}
