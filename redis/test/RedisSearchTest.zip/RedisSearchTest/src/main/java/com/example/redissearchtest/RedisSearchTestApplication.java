package com.example.redissearchtest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RedisSearchTestApplication {

    public static void main(String[] args) {
        SpringApplication.run(RedisSearchTestApplication.class, args);
    }

}
