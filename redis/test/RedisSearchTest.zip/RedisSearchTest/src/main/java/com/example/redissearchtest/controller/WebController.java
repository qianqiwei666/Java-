package com.example.redissearchtest.controller;

import com.example.redissearchtest.User;
import com.qianqiwei.code.RedisSearchCommand;
import io.redisearch.Document;
import io.redisearch.FieldName;
import io.redisearch.Query;
import io.redisearch.Schema;
import io.redisearch.client.IndexDefinition;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

/**
 * @author : 钱琪炜
 * @date : 2022/7/2
 */
@RestController
public class WebController {

    @Autowired
    private RedisSearchCommand redisSearchCommand;
    String indexName="qianqiwei";
    @GetMapping("/load")
    public void load() {
//        redisSearchCommand.dropIndex(indexName);
        IndexDefinition indexDefinition=new IndexDefinition();
        indexDefinition.setLanguage("chinese");
        Schema schema=new Schema();
        schema.addField(new Schema.Field(FieldName.of("username"), Schema.FieldType.FullText));
        schema.addNumericField("age");
        schema.addField(new Schema.Field(FieldName.of("address"), Schema.FieldType.FullText));
        redisSearchCommand.createIndex(indexName,indexDefinition,schema);
        List<User> users=new ArrayList<>();
        users.add(new User("钱 琪 炜",13,"湖 北 宜 昌"));
        users.add(new User("张 三",15,"湖 北 武 汉"));
        users.add(new User("李 四",67,"湖 北 皇 室"));
        users.add(new User("王 武",45,"湖 北 酒 店"));
        users.add(new User("赵 六",56,"湖 北 医 院"));
        users.add(new User("田 七",34,"湖 北 日 本"));
        users.add(new User("小 码",67,"湖 北 九 州"));
        users.add(new User("赵 子 龙",23,"湖 北 黄 沾"));
        users.add(new User("王 安 石",45,"湖 北 九 门"));
        users.add(new User("李 白",12,"湖 北 把 关"));
        users.add(new User("小 李 子",45,"湖 北 立 本"));
        users.add(new User("就 骂 吧",56,"湖 北 发 给 对 方"));
        users.add(new User("手 机",12,"湖 更 好"));
        users.add(new User("华 为",23,"湖 北 第 三 方"));
        users.add(new User("o p p o",34,"湖 北 让 他"));
        users.add(new User("日 本",67,"湖 北 第 三 方"));
        redisSearchCommand.createIndexDocumentByObj(indexName,users);
    }

    @GetMapping("/query")
    public List<Document> query(@RequestParam("value")String value){
        Query query=new Query(value);
        query.setLanguage("chinese");
        query.highlightFields("username");
        List<Document> queryList = redisSearchCommand.query(indexName, query);
        return queryList;
    }
}