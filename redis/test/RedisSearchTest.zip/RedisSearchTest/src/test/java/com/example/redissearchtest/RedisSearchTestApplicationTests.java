package com.example.redissearchtest;

import com.qianqiwei.code.RedisSearchCommand;
import io.redisearch.Document;
import io.redisearch.FieldName;
import io.redisearch.Query;
import io.redisearch.Schema;
import io.redisearch.client.IndexDefinition;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.ArrayList;
import java.util.List;

@SpringBootTest
class RedisSearchTestApplicationTests {

    @Test
    void contextLoads() {



    }

}
