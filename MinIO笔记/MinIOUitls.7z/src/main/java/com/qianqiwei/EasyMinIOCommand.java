package com.qianqiwei;

import com.google.common.io.ByteStreams;
import io.minio.*;
import io.minio.errors.*;
import io.minio.messages.Bucket;
import io.minio.messages.Item;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.List;

/**
 * @Author 钱琪炜
 * @Date 2022/4/29 16:10
 * @Version 1.0
 */
public class EasyMinIOCommand extends MinIOCommand {

    public EasyMinIOCommand(String address, String username, String password) {
        super(address, username, password);
    }

    @Override
    public boolean bucketExits(String bucketName) throws ServerException, InsufficientDataException, ErrorResponseException, IOException, NoSuchAlgorithmException, InvalidKeyException, InvalidResponseException, XmlParserException, InternalException {
        return minioClient().bucketExists(BucketExistsArgs.builder().bucket(bucketName).build());
    }

    @Override
    public List<Bucket> allBucket() throws ServerException, InsufficientDataException, ErrorResponseException, IOException, NoSuchAlgorithmException, InvalidKeyException, InvalidResponseException, XmlParserException, InternalException {
        return minioClient().listBuckets();
    }

    @Override
    public void makeBucket(String bucketName) throws ServerException, InsufficientDataException, ErrorResponseException, IOException, NoSuchAlgorithmException, InvalidKeyException, InvalidResponseException, XmlParserException, InternalException {
        minioClient().makeBucket(MakeBucketArgs.builder().bucket(bucketName).build());
    }

    @Override
    public void removeBucket(String bucketName) throws ServerException, InsufficientDataException, ErrorResponseException, IOException, NoSuchAlgorithmException, InvalidKeyException, InvalidResponseException, XmlParserException, InternalException {
        minioClient().removeBucket(RemoveBucketArgs.builder().bucket(bucketName).build());
    }

    @Override
    public void uploadObject(String bucketName, String uploadObjectName, String absoluteLocalPath) throws IOException, ServerException, InsufficientDataException, ErrorResponseException, NoSuchAlgorithmException, InvalidKeyException, InvalidResponseException, XmlParserException, InternalException {
        minioClient().uploadObject(UploadObjectArgs.builder().bucket(bucketName).object(uploadObjectName).filename(absoluteLocalPath).build());
    }

    @Override
    public void removeObject(String bucketName, String objectName) throws ServerException, InsufficientDataException, ErrorResponseException, IOException, NoSuchAlgorithmException, InvalidKeyException, InvalidResponseException, XmlParserException, InternalException {
        minioClient().removeObject(RemoveObjectArgs.builder().bucket(bucketName).object(objectName).build());
    }

    @Override
    public void downloadObject(String bucketName, String DownloadObjectName, String absoluteLocalPath) throws ServerException, InsufficientDataException, ErrorResponseException, IOException, NoSuchAlgorithmException, InvalidKeyException, InvalidResponseException, XmlParserException, InternalException {
        minioClient().downloadObject(DownloadObjectArgs.builder().bucket(bucketName).object(DownloadObjectName).filename(absoluteLocalPath).build());
    }

    @Override
    public Iterable<Result<Item>> allObjectName(String bucketName) {
        return minioClient().listObjects(ListObjectsArgs.builder().bucket(bucketName).build());
    }

    public InputStream downloadFile(String bucketName, String objectName) throws ServerException, InsufficientDataException, ErrorResponseException, IOException, NoSuchAlgorithmException, InvalidKeyException, InvalidResponseException, XmlParserException, InternalException {
        return minioClient().getObject(GetObjectArgs.builder().bucket(bucketName).object(objectName).build());
    }

    @Override
    public void downloadFileByResponse(String bucketName, String objectName, OutputStream outputStream) throws ServerException, InsufficientDataException, ErrorResponseException, IOException, NoSuchAlgorithmException, InvalidKeyException, InvalidResponseException, XmlParserException, InternalException {
        InputStream inputStream = downloadFile(bucketName, objectName);
        ByteStreams.copy(inputStream, outputStream);
    }

    public StatObjectResponse statObject(String bucketName, String objectName) throws ServerException, InsufficientDataException, ErrorResponseException, IOException, NoSuchAlgorithmException, InvalidKeyException, InvalidResponseException, XmlParserException, InternalException {
        return minioClient().statObject(StatObjectArgs.builder().bucket(bucketName).object(objectName).build());
    }
}
