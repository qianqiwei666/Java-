package com.qianqiwei;

import io.minio.MinioClient;
import io.minio.Result;
import io.minio.StatObjectResponse;
import io.minio.errors.*;
import io.minio.messages.Bucket;
import io.minio.messages.Item;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.List;

/**
 * @Author 钱琪炜
 * @Date 2022/4/29 15:57
 * @Version 1.0
 */
public abstract class MinIOCommand {

    private MinioClient minioClient;

    //获取客户端
    public MinIOCommand(String address, String username, String password) {
        MinioClient minioClient = MinioClient.builder().endpoint(address).credentials(username, password).build();
        this.minioClient = minioClient;
    }

    public MinioClient minioClient() {
        return minioClient;
    }

    //bucket是否存在
    public abstract boolean bucketExits(String bucketName) throws ServerException, InsufficientDataException, ErrorResponseException, IOException, NoSuchAlgorithmException, InvalidKeyException, InvalidResponseException, XmlParserException, InternalException;

    //获取所有的bucket
    public abstract List<Bucket> allBucket() throws ServerException, InsufficientDataException, ErrorResponseException, IOException, NoSuchAlgorithmException, InvalidKeyException, InvalidResponseException, XmlParserException, InternalException;

    //添加bucket
    public abstract void makeBucket(String bucketName) throws ServerException, InsufficientDataException, ErrorResponseException, IOException, NoSuchAlgorithmException, InvalidKeyException, InvalidResponseException, XmlParserException, InternalException;

    //删除bucket
    public abstract void removeBucket(String bucketName) throws ServerException, InsufficientDataException, ErrorResponseException, IOException, NoSuchAlgorithmException, InvalidKeyException, InvalidResponseException, XmlParserException, InternalException;

    //上传object 注意:object以/可以分配目录
    public abstract void uploadObject(String bucketName, String uploadObjectName, String absoluteLocalPath) throws IOException, ServerException, InsufficientDataException, ErrorResponseException, NoSuchAlgorithmException, InvalidKeyException, InvalidResponseException, XmlParserException, InternalException;

    //删除object
    public abstract void removeObject(String bucketName, String objectName) throws ServerException, InsufficientDataException, ErrorResponseException, IOException, NoSuchAlgorithmException, InvalidKeyException, InvalidResponseException, XmlParserException, InternalException;

    //下载object
    public abstract void downloadObject(String bucketName, String DownloadObjectName, String absoluteLocalPath) throws ServerException, InsufficientDataException, ErrorResponseException, IOException, NoSuchAlgorithmException, InvalidKeyException, InvalidResponseException, XmlParserException, InternalException;

    //获取当前bucket所有的Object信息
    public abstract Iterable<Result<Item>> allObjectName(String bucketName);

    //通过字节流下载文件
    public abstract InputStream downloadFile(String bucketName, String objectName) throws ServerException, InsufficientDataException, ErrorResponseException, IOException, NoSuchAlgorithmException, InvalidKeyException, InvalidResponseException, XmlParserException, InternalException;

    //下载通过ServletHttpResponse
    public abstract void downloadFileByResponse(String bucketName, String objectName, OutputStream outputStream) throws ServerException, InsufficientDataException, ErrorResponseException, IOException, NoSuchAlgorithmException, InvalidKeyException, InvalidResponseException, XmlParserException, InternalException;

    //获取对象的信息
    public abstract StatObjectResponse statObject(String bucketName, String objectName) throws ServerException, InsufficientDataException, ErrorResponseException, IOException, NoSuchAlgorithmException, InvalidKeyException, InvalidResponseException, XmlParserException, InternalException;


}
