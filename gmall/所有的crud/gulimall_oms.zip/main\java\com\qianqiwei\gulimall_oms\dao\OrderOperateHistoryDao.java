package com.qianqiwei.gulimall_oms.dao;

import com.qianqiwei.gulimall_oms.entity.OrderOperateHistoryEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 订单操作历史记录
 * 
 * @author qianqiwei
 * @email 1591500761@qq.com
 * @date 2022-07-11 17:08:40
 */
@Mapper
public interface OrderOperateHistoryDao extends BaseMapper<OrderOperateHistoryEntity> {
	
}
