package com.qianqiwei.gulimall_sms.dao;

import com.qianqiwei.gulimall_sms.entity.CouponHistoryEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 优惠券领取历史记录
 * 
 * @author qianqiwei
 * @email 1591500761@qq.com
 * @date 2022-07-18 09:05:59
 */
@Mapper
public interface CouponHistoryDao extends BaseMapper<CouponHistoryEntity> {
	
}
