package com.qianqiwei.gulimall_sms.dao;

import com.qianqiwei.gulimall_sms.entity.SkuFullReductionEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 商品满减信息
 * 
 * @author qianqiwei
 * @email 1591500761@qq.com
 * @date 2022-07-18 09:05:59
 */
@Mapper
public interface SkuFullReductionDao extends BaseMapper<SkuFullReductionEntity> {
	
}
