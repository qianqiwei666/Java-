package com.qianqiwei.gulimall_pms.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.qianqiwei.common.utils.PageUtils;
import com.qianqiwei.gulimall_pms.entity.SkuInfoEntity;

import java.util.Map;

/**
 * sku信息
 *
 * @author qianqiwei
 * @email 1591500761@qq.com
 * @date 2022-07-11 17:13:11
 */
public interface SkuInfoService extends IService<SkuInfoEntity> {

    PageUtils queryPage(Map<String, Object> params);
}

