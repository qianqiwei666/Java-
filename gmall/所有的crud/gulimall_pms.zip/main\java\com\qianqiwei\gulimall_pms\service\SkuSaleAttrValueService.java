package com.qianqiwei.gulimall_pms.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.qianqiwei.common.utils.PageUtils;
import com.qianqiwei.gulimall_pms.entity.SkuSaleAttrValueEntity;

import java.util.Map;

/**
 * sku销售属性&值
 *
 * @author qianqiwei
 * @email 1591500761@qq.com
 * @date 2022-07-11 17:13:11
 */
public interface SkuSaleAttrValueService extends IService<SkuSaleAttrValueEntity> {

    PageUtils queryPage(Map<String, Object> params);
}

