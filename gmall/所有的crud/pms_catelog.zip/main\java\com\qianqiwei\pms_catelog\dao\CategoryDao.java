package com.qianqiwei.pms_catelog.dao;

import com.qianqiwei.pms_catelog.entity.CategoryEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 商品三级分类
 * 
 * @author qianqiwei
 * @email 1591500761@qq.com
 * @date 2022-07-11 17:16:31
 */
@Mapper
public interface CategoryDao extends BaseMapper<CategoryEntity> {
	
}
