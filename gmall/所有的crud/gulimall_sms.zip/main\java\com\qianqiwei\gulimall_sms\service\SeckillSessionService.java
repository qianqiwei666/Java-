package com.qianqiwei.gulimall_sms.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.qianqiwei.common.utils.PageUtils;
import com.qianqiwei.gulimall_sms.entity.SeckillSessionEntity;

import java.util.Map;

/**
 * 秒杀活动场次
 *
 * @author qianqiwei
 * @email 1591500761@qq.com
 * @date 2022-07-11 17:13:56
 */
public interface SeckillSessionService extends IService<SeckillSessionEntity> {

    PageUtils queryPage(Map<String, Object> params);
}

