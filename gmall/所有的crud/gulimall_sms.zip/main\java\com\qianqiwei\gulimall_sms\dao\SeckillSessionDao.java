package com.qianqiwei.gulimall_sms.dao;

import com.qianqiwei.gulimall_sms.entity.SeckillSessionEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 秒杀活动场次
 * 
 * @author qianqiwei
 * @email 1591500761@qq.com
 * @date 2022-07-11 17:13:56
 */
@Mapper
public interface SeckillSessionDao extends BaseMapper<SeckillSessionEntity> {
	
}
