package com.qianqiwei.gulimall_pms.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.qianqiwei.common.utils.PageUtils;
import com.qianqiwei.gulimall_pms.entity.AttrEntity;

import java.util.Map;

/**
 * 商品属性
 *
 * @author qianqiwei
 * @email 1591500761@qq.com
 * @date 2022-07-18 09:04:21
 */
public interface AttrService extends IService<AttrEntity> {

    PageUtils queryPage(Map<String, Object> params);
}

