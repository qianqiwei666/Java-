package com.qianqiwei.gulimall_pms.dao;

import com.qianqiwei.gulimall_pms.entity.AttrAttrgroupRelationEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 属性&属性分组关联
 * 
 * @author qianqiwei
 * @email 1591500761@qq.com
 * @date 2022-07-18 09:04:21
 */
@Mapper
public interface AttrAttrgroupRelationDao extends BaseMapper<AttrAttrgroupRelationEntity> {
	
}
