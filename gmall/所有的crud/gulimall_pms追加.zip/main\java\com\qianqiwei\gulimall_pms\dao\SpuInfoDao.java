package com.qianqiwei.gulimall_pms.dao;

import com.qianqiwei.gulimall_pms.entity.SpuInfoEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * spu信息
 * 
 * @author qianqiwei
 * @email 1591500761@qq.com
 * @date 2022-07-18 09:04:21
 */
@Mapper
public interface SpuInfoDao extends BaseMapper<SpuInfoEntity> {
	
}
