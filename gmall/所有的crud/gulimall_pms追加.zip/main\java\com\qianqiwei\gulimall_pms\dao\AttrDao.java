package com.qianqiwei.gulimall_pms.dao;

import com.qianqiwei.gulimall_pms.entity.AttrEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 商品属性
 * 
 * @author qianqiwei
 * @email 1591500761@qq.com
 * @date 2022-07-18 09:04:21
 */
@Mapper
public interface AttrDao extends BaseMapper<AttrEntity> {
	
}
