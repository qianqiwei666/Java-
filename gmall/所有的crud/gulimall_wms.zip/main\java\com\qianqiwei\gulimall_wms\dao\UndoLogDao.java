package com.qianqiwei.gulimall_wms.dao;

import com.qianqiwei.gulimall_wms.entity.UndoLogEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 
 * 
 * @author qianqiwei
 * @email 1591500761@qq.com
 * @date 2022-07-11 17:15:29
 */
@Mapper
public interface UndoLogDao extends BaseMapper<UndoLogEntity> {
	
}
