package com.qianqiwei.gulimall_wms.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.qianqiwei.common.utils.PageUtils;
import com.qianqiwei.gulimall_wms.entity.PurchaseDetailEntity;

import java.util.Map;

/**
 * 
 *
 * @author qianqiwei
 * @email 1591500761@qq.com
 * @date 2022-07-11 17:15:29
 */
public interface PurchaseDetailService extends IService<PurchaseDetailEntity> {

    PageUtils queryPage(Map<String, Object> params);
}

