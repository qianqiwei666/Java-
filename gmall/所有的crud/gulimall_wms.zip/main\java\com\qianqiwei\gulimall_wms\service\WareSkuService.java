package com.qianqiwei.gulimall_wms.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.qianqiwei.common.utils.PageUtils;
import com.qianqiwei.gulimall_wms.entity.WareSkuEntity;

import java.util.Map;

/**
 * 商品库存
 *
 * @author qianqiwei
 * @email 1591500761@qq.com
 * @date 2022-07-11 17:15:29
 */
public interface WareSkuService extends IService<WareSkuEntity> {

    PageUtils queryPage(Map<String, Object> params);
}

