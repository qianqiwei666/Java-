package com.qianqiwei.gulimall_ums.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.qianqiwei.common.utils.PageUtils;
import com.qianqiwei.gulimall_ums.entity.MemberCollectSpuEntity;

import java.util.Map;

/**
 * 会员收藏的商品
 *
 * @author qianqiwei
 * @email 1591500761@qq.com
 * @date 2022-07-11 17:14:43
 */
public interface MemberCollectSpuService extends IService<MemberCollectSpuEntity> {

    PageUtils queryPage(Map<String, Object> params);
}

