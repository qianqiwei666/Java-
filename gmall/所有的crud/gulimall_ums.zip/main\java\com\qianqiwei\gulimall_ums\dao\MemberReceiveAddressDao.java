package com.qianqiwei.gulimall_ums.dao;

import com.qianqiwei.gulimall_ums.entity.MemberReceiveAddressEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 会员收货地址
 * 
 * @author qianqiwei
 * @email 1591500761@qq.com
 * @date 2022-07-11 17:14:43
 */
@Mapper
public interface MemberReceiveAddressDao extends BaseMapper<MemberReceiveAddressEntity> {
	
}
