package com.qianqiwei.gulimall_ums.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.qianqiwei.common.utils.PageUtils;
import com.qianqiwei.gulimall_ums.entity.MemberStatisticsInfoEntity;

import java.util.Map;

/**
 * 会员统计信息
 *
 * @author qianqiwei
 * @email 1591500761@qq.com
 * @date 2022-07-11 17:14:43
 */
public interface MemberStatisticsInfoService extends IService<MemberStatisticsInfoEntity> {

    PageUtils queryPage(Map<String, Object> params);
}

