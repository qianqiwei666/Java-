package com.qianqiwei.gulimall_ums.dao;

import com.qianqiwei.gulimall_ums.entity.IntegrationChangeHistoryEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 积分变化历史记录
 * 
 * @author qianqiwei
 * @email 1591500761@qq.com
 * @date 2022-07-11 17:14:43
 */
@Mapper
public interface IntegrationChangeHistoryDao extends BaseMapper<IntegrationChangeHistoryEntity> {
	
}
