package com.qianqiwei.dubboconsumer.controller;

import com.qianqiwei.dubboconsumer.service.WebServiceImpl;
import com.qianqiwei.service.WebService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;


@RestController
public class WebController {


    @Autowired
    private WebServiceImpl webServiceImpl;

    @GetMapping("/getUser")
    public Object getUser() {
        return webServiceImpl.getUser();
    }

    @GetMapping("/getMap")
    public Map<String, Object> getMap() {
        return webServiceImpl.getMap();
    }

    @GetMapping("/getStr")
    public String getStr() {
        return webServiceImpl.getStr();
    }
}
