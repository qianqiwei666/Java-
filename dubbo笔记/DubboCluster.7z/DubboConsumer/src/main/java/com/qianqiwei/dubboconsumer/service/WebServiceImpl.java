package com.qianqiwei.dubboconsumer.service;

import com.alibaba.nacos.shaded.org.checkerframework.checker.units.qual.A;
import com.qianqiwei.service.WebService;
import org.apache.dubbo.config.annotation.DubboReference;
import org.apache.dubbo.config.annotation.Method;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

@Service
public class WebServiceImpl implements WebService {


    @DubboReference(version = "2.0", check = false)
    private WebService webService;


    @Override
    public Object getUser() {
        return webService.getUser();
    }

    @Override
    public Map<String, Object> getMap() {
        return webService.getMap();
    }

    @Override
    public String getStr() {
        return webService.getStr();
    }
}
