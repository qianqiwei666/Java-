package com.qianqiwei.dubboprovider02.service;

import com.qianqiwei.dubboprovider02.pojo.User;
import com.qianqiwei.service.WebService;
import org.apache.dubbo.config.annotation.DubboService;
import org.springframework.http.ResponseEntity;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;


@DubboService(interfaceClass = WebService.class)
public class WebServiceImpl implements WebService {

    @Override
    public Object getUser() {
        try {
            TimeUnit.SECONDS.sleep(3);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        User user=new User("刘德华","liudehua","上海");
        return user;
    }

    @Override
    public Map<String, Object> getMap() {
        Map<String,Object> map=new HashMap<>();
        map.put("serverName","provider02");
        map.put("port","8083");
        return map;
    }

    @Override
    public String getStr() {
        return "你好我是provider02";
    }


}
