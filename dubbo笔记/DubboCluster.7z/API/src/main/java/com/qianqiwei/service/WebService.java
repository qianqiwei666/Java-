package com.qianqiwei.service;

import java.util.Map;

public interface WebService {

    public Object getUser();

    public Map<String,Object> getMap();

    public String getStr();
}
