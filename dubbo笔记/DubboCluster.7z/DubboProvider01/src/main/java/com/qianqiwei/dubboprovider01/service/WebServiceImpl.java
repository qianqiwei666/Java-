package com.qianqiwei.dubboprovider01.service;

import com.qianqiwei.dubboprovider01.pojo.User;
import com.qianqiwei.service.WebService;
import org.apache.dubbo.config.annotation.DubboService;
import org.springframework.http.ResponseEntity;

import java.util.HashMap;
import java.util.Map;


@DubboService(version = "1.0",interfaceClass = WebService.class)
public class WebServiceImpl implements WebService {
    @Override
    public Object getUser() {
        User user=new User("钱琪炜","qianqiwei","武汉");
        return user;
    }

    @Override
    public Map<String,Object> getMap() {
        Map<String,Object> map=new HashMap<>();
        map.put("serverName","provider01");
        map.put("port","8082");
        return map;
    }

    @Override
    public String getStr() {
        return "你好provider01";
    }
}
