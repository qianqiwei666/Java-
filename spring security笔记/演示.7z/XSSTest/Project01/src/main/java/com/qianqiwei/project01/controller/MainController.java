package com.qianqiwei.project01.controller;


import jdk.nashorn.internal.objects.annotations.Getter;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class MainController {

    @GetMapping("/index")
    public String index(){
        System.out.println("8080页面被访问了");
        return "index";
    }
}
