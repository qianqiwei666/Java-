package com.qianqiwei.project02;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Project02ApplicationTests {

    @Test
    void contextLoads() {
    }

}
