package com.qianqiwei.project02.controller;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class MainController {

    @GetMapping("view")
    public String view(){
        System.out.println("8081被成功的访问了");
        return "index";
    }


}
