package com.qianqiwei.project01.config;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.security.web.csrf.HttpSessionCsrfTokenRepository;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@Configuration
public class SecurityConfig extends WebSecurityConfigurerAdapter {

    //配置拦截逻辑
    @Override
    protected void configure(HttpSecurity http) throws Exception {
        //设置哪些请求需要被验证
        http.authorizeRequests()
                .antMatchers("/success","/")//设置需要校验的路径 如果是any的话,之后不能做放行
                .authenticated()
                .antMatchers("/fail")//放行路径
                .permitAll()
                .and()
                .formLogin()//自定义登录配置
                .loginPage("/loginPage")//自定义登录界面
                .loginProcessingUrl("/test/login")//自定义认证路径
                .permitAll()//放行所有的请求
                .passwordParameter("username")
                .passwordParameter("password")
                .successHandler(new AuthenticationSuccessHandler() {
                    @Override
                    public void onAuthenticationSuccess(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Authentication authentication) throws IOException, ServletException {
                        httpServletResponse.sendRedirect("/success");
                    }
                })
                .failureHandler(new AuthenticationFailureHandler() {
                    @Override
                    public void onAuthenticationFailure(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, AuthenticationException e) throws IOException, ServletException {
                        httpServletResponse.sendRedirect("/fail");
                    }
                })
                .and()
                .csrf()
                .disable();//关闭csrf 如果开启就会下发hash值去进行验证
    }
    //配置验证逻辑
    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        //手动设置用户名与密码(创建临时的用户名与密码)
        auth.inMemoryAuthentication()
                //配置多个用户名与密码(必须加密)
                .withUser("liudehua")
                .password(new BCryptPasswordEncoder().encode("liudehua"))
                .roles("admin")
                .and()
                .withUser("qianqiwei")
                .password(new BCryptPasswordEncoder().encode("qianqiwei"))
                .roles("root");
    }

    @Bean
    public PasswordEncoder passwordEncoder(){
        return new BCryptPasswordEncoder();
    }


}
