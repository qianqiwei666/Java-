package com.qianqiwei;

import com.qianqiwei.utilBean.DocBean;
import org.apache.http.HttpHost;
import org.elasticsearch.ElasticsearchException;
import org.elasticsearch.ElasticsearchStatusException;
import org.elasticsearch.action.bulk.BulkResponse;
import org.elasticsearch.action.delete.DeleteResponse;
import org.elasticsearch.action.get.GetRequest;
import org.elasticsearch.action.get.GetResponse;
import org.elasticsearch.action.index.IndexResponse;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.update.UpdateResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.client.indices.CreateIndexRequest;
import org.elasticsearch.client.indices.CreateIndexResponse;
import org.elasticsearch.client.indices.GetIndexResponse;
import org.elasticsearch.common.Nullable;
import org.elasticsearch.index.Index;
import org.elasticsearch.index.IndexNotFoundException;
import org.elasticsearch.index.query.RangeQueryBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilder;
import org.elasticsearch.search.fetch.subphase.highlight.HighlightBuilder;
import org.elasticsearch.search.sort.SortOrder;


import java.io.IOException;
import java.util.List;
import java.util.Map;

/**
 * @Author 钱琪炜
 * @Date 2022/5/10 19:17
 * @Version 2.2
 */
public abstract class ESCommand {
    private RestHighLevelClient client;


    protected ESCommand(String host, int port, String scheme) {
        if (client == null) this.client = new RestHighLevelClient(RestClient.builder(new HttpHost(host, port, scheme)));
    }

    public RestHighLevelClient client() {
        return client;
    }

    public abstract boolean createIndex(String index);

    public abstract GetIndexResponse getIndexResponse(String index);

    public abstract boolean deleteIndex(String index);

    public abstract IndexResponse createDocJson(String index, @Nullable String id, Object obj);


    public abstract UpdateResponse updateDocJson(String index, String id, Map<String, Object> updateMap);


    public abstract DeleteResponse deleteDocJson(String index, String id);


    public abstract GetResponse getDocJson(String index, String id);


    public abstract BulkResponse createDocJsonBatch(List<DocBean> docBeanList);


    public abstract BulkResponse deleteDocJsonBatch(List<DocBean> docBeanList);


    public abstract SearchResponse searchDocByIndexs(String[] index, int from, int size, @Nullable String field, @Nullable SortOrder sortOrder, @Nullable String includes[], @Nullable String excludes[], @Nullable RangeQueryBuilder rangeQueryBuilder, @Nullable AggregationBuilder aggregationBuilder);


    public abstract SearchResponse searchDocByResultBlurry(String index, String key, Object value, int from, int size, @Nullable String field, @Nullable SortOrder sortOrder, @Nullable String includes[], @Nullable String excludes[], @Nullable RangeQueryBuilder rangeQueryBuilder, @Nullable HighlightBuilder highlightBuilder, @Nullable AggregationBuilder aggregationBuilder);

    public abstract SearchResponse searchDocByResultExact(String index, String key, Object value, int from, int size, @Nullable String field, @Nullable SortOrder sortOrder, @Nullable String includes[], @Nullable String excludes[], @Nullable RangeQueryBuilder rangeQueryBuilder, @Nullable HighlightBuilder highlightBuilder, @Nullable AggregationBuilder aggregationBuilder);


    public abstract SearchResponse searchDocByAndResult(String index, Map<String, Object> result, int from, int size, @Nullable String field, @Nullable SortOrder sortOrder, @Nullable String includes[], @Nullable String excludes[], Boolean isExact, @Nullable RangeQueryBuilder rangeQueryBuilder, @Nullable HighlightBuilder highlightBuilder, @Nullable AggregationBuilder aggregationBuilder);

    public abstract SearchResponse searchDocByOrResult(String index, Map<String, Object> result, int from, int size, @Nullable String field, @Nullable SortOrder sortOrder, @Nullable String includes[], @Nullable String excludes[], Boolean isExact, @Nullable RangeQueryBuilder rangeQueryBuilder, @Nullable HighlightBuilder highlightBuilder, @Nullable AggregationBuilder aggregationBuilder);

    public abstract SearchResponse searchDocNotByAndResult(String index, Map<String, Object> result, int from, int size, @Nullable String field, @Nullable SortOrder sortOrder, @Nullable String includes[], @Nullable String excludes[], Boolean isExact, @Nullable RangeQueryBuilder rangeQueryBuilder, @Nullable HighlightBuilder highlightBuilder, @Nullable AggregationBuilder aggregationBuilder);

    public abstract Long getItemCountByIndex(String index);

}
