package com.qianqiwei.utilBean;

/**
 * @Author 钱琪炜
 * @Date 2022/5/10 22:26
 * @Version 1.0
 */
public class DocBean {
    private String index;
    private String id;
    private Object value;


    public DocBean(String index, String id) {
        this.index = index;
        this.id = id;
    }

    public DocBean(String index, String id, Object value) {
        this.index = index;
        this.id = id;
        this.value = value;
    }

    public String getIndex() {
        return index;
    }

    public void setIndex(String index) {
        this.index = index;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Object getValue() {
        return value;
    }

    public void setValue(Object value) {
        this.value = value;
    }
}
