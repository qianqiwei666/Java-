package com.qianqiwei;

import com.alibaba.fastjson.JSONObject;
import com.qianqiwei.utilBean.DocBean;
import org.elasticsearch.ElasticsearchStatusException;
import org.elasticsearch.action.admin.indices.delete.DeleteIndexRequest;
import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.action.bulk.BulkResponse;
import org.elasticsearch.action.delete.DeleteRequest;
import org.elasticsearch.action.delete.DeleteResponse;
import org.elasticsearch.action.get.GetRequest;
import org.elasticsearch.action.get.GetResponse;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.index.IndexResponse;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.update.UpdateRequest;
import org.elasticsearch.action.update.UpdateResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.core.CountRequest;
import org.elasticsearch.client.indices.CreateIndexRequest;
import org.elasticsearch.client.indices.CreateIndexResponse;
import org.elasticsearch.client.indices.GetIndexRequest;
import org.elasticsearch.client.indices.GetIndexResponse;
import org.elasticsearch.common.Nullable;
import org.elasticsearch.common.xcontent.XContentType;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.query.RangeQueryBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilder;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.elasticsearch.search.fetch.subphase.highlight.HighlightBuilder;
import org.elasticsearch.search.sort.SortOrder;

import java.io.IOException;
import java.util.List;
import java.util.Map;

/**
 * @Author 钱琪炜
 * @Date 2022/5/10 20:32
 * @Version 1.0
 */
public class SimpleESCommand extends ESCommand {

    public SimpleESCommand(String host, int port, String scheme) {
        super(host, port, scheme);
    }

    /**
     * 指定创建哪个index
     *
     * @param index
     * @return
     */
    @Override
    public boolean createIndex(String index) {
        try {
            //查询失败就会报错
            client().indices().create(new CreateIndexRequest(index), RequestOptions.DEFAULT);
            return true;
        } catch (ElasticsearchStatusException | IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 指定获取哪个index
     *
     * @param index
     * @return
     */
    @Override
    public GetIndexResponse getIndexResponse(String index) {
        try {
            return client().indices().get(new GetIndexRequest(index), RequestOptions.DEFAULT);
        } catch (ElasticsearchStatusException | IOException e) {
            e.printStackTrace();
            return null;
        }
    }


    /**
     * 指定删除哪个index
     *
     * @param index
     * @return
     */

    @Override
    public boolean deleteIndex(String index) {
        try {
            client().indices().delete(new DeleteIndexRequest(index), RequestOptions.DEFAULT);
            return true;
        } catch (ElasticsearchStatusException | IOException e) {
            e.printStackTrace();
            return false;
        }
    }


    /**
     * 存储数据,也可用于id全局修改
     *
     * @param index 指定index
     * @param id    指定创建数据id
     * @param obj   指定存储对象
     * @return
     */
    @Override
    public IndexResponse createDocJson(String index, @Nullable String id, Object obj) {
        IndexRequest indexRequest = new IndexRequest();
        String json = JSONObject.toJSONString(obj);
        if (id == null) {
            indexRequest.index(index).source(json, XContentType.JSON);
        } else {
            indexRequest.index(index).id(id).source(json, XContentType.JSON);
        }
        try {
            IndexResponse indexResponse = client().index(indexRequest, RequestOptions.DEFAULT);
            return indexResponse;
        } catch (ElasticsearchStatusException | IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * 修改局部数据
     *
     * @param index     指定index
     * @param id        指定创建数据id
     * @param updateMap 指定局部修改的值
     * @return
     */
    @Override
    public UpdateResponse updateDocJson(String index, String id, Map<String, Object> updateMap) {
        UpdateRequest updateRequest = new UpdateRequest();
        updateRequest.index(index).id(id);
        updateRequest.doc(updateMap, XContentType.JSON);
        try {
            return client().update(updateRequest, RequestOptions.DEFAULT);
        } catch (ElasticsearchStatusException | IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * 删除当前index指定id数据
     *
     * @param index 指定的index
     * @param id    指定id
     * @return
     */

    @Override
    public DeleteResponse deleteDocJson(String index, String id) {
        DeleteRequest deleteRequest = new DeleteRequest();
        deleteRequest.index(index).id(id);
        try {
            return client().delete(deleteRequest, RequestOptions.DEFAULT);
        } catch (ElasticsearchStatusException | IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * 获取当前index下指定id数据
     *
     * @param index 指定的index
     * @param id    指定id
     * @return
     */

    @Override
    public GetResponse getDocJson(String index, String id) {
        GetRequest getRequest = new GetRequest();
        getRequest.index(index).id(id);
        try {
            return client().get(getRequest, RequestOptions.DEFAULT);
        } catch (ElasticsearchStatusException | IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * 批量创建数据
     *
     * @param docBeanList 数据bean
     * @return
     */
    @Override
    public BulkResponse createDocJsonBatch(List<DocBean> docBeanList) {
        BulkRequest bulkRequest = new BulkRequest();
        docBeanList.forEach(item -> {
            if (item.getId() == null) {
                bulkRequest.add(new IndexRequest().index(item.getIndex()).source(JSONObject.toJSONString(item.getValue())));
            } else {
                bulkRequest.add(new IndexRequest().index(item.getIndex()).id(item.getId()).source(JSONObject.toJSONString(item.getValue()), XContentType.JSON));
            }
        });
        try {
            return client().bulk(bulkRequest, RequestOptions.DEFAULT);
        } catch (ElasticsearchStatusException | IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * 批量删除数据
     *
     * @param docBeanList
     * @return
     */

    @Override
    public BulkResponse deleteDocJsonBatch(List<DocBean> docBeanList) {
        BulkRequest bulkRequest = new BulkRequest();
        docBeanList.forEach(item -> {
            bulkRequest.add(new DeleteRequest().index(item.getIndex()).id(item.getId()));
        });
        try {
            return client().bulk(bulkRequest, RequestOptions.DEFAULT);
        } catch (ElasticsearchStatusException | IOException e) {
            e.printStackTrace();
            return null;
        }
    }


    /**
     * 分页查询指定哪些index
     * 提示:form=(页码-1)*size
     *
     * @param index 查询哪个index
     * @param from  数据展示起始位置
     * @param size  数据一次展示多少个数据
     * @return
     */
    @Override
    public SearchResponse searchDocByIndexs(String[] index, int from, int size, @Nullable String field, @Nullable SortOrder sortOrder, @Nullable String includes[], @Nullable String excludes[], @Nullable RangeQueryBuilder rangeQueryBuilder, @Nullable AggregationBuilder aggregationBuilder) {
        SearchRequest searchRequest = new SearchRequest();
        searchRequest.indices(index);
        if (field == null && sortOrder == null) {
            if (rangeQueryBuilder != null) {
                if (aggregationBuilder != null) {
                    searchRequest.source(new SearchSourceBuilder().query(QueryBuilders.matchAllQuery()).from(from).size(size).fetchSource(includes, excludes).postFilter(rangeQueryBuilder).aggregation(aggregationBuilder));
                } else {
                    searchRequest.source(new SearchSourceBuilder().query(QueryBuilders.matchAllQuery()).from(from).size(size).fetchSource(includes, excludes).postFilter(rangeQueryBuilder));
                }
            } else {
                if (aggregationBuilder != null) {
                    searchRequest.source(new SearchSourceBuilder().query(QueryBuilders.matchAllQuery()).from(from).size(size).fetchSource(includes, excludes).aggregation(aggregationBuilder));
                } else {
                    searchRequest.source(new SearchSourceBuilder().query(QueryBuilders.matchAllQuery()).from(from).size(size).fetchSource(includes, excludes));
                }

            }

        } else {
            if (rangeQueryBuilder != null) {
                if (aggregationBuilder != null) {
                    searchRequest.source(new SearchSourceBuilder().query(QueryBuilders.matchAllQuery()).from(from).size(size).sort(field, sortOrder).fetchSource(includes, excludes).postFilter(rangeQueryBuilder).aggregation(aggregationBuilder));
                } else {
                    searchRequest.source(new SearchSourceBuilder().query(QueryBuilders.matchAllQuery()).from(from).size(size).sort(field, sortOrder).fetchSource(includes, excludes).postFilter(rangeQueryBuilder));
                }
            } else {
                if (aggregationBuilder != null) {
                    searchRequest.source(new SearchSourceBuilder().query(QueryBuilders.matchAllQuery()).from(from).size(size).sort(field, sortOrder).fetchSource(includes, excludes).aggregation(aggregationBuilder));
                } else {
                    searchRequest.source(new SearchSourceBuilder().query(QueryBuilders.matchAllQuery()).from(from).size(size).sort(field, sortOrder).fetchSource(includes, excludes));
                }
            }

        }
        try {
            return client().search(searchRequest, RequestOptions.DEFAULT);
        } catch (ElasticsearchStatusException | IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * 模糊查询
     *
     * @param index 查询哪个index
     * @param key   查询数据的key
     * @param value 查询数据的value
     * @param from  数据展示起始位置
     * @param size  数据一次展示多少个数据
     * @return
     */

    public SearchResponse searchDocByResultBlurry(String index, String key, Object value, int from, int size, @Nullable String field, @Nullable SortOrder sortOrder, @Nullable String includes[], @Nullable String excludes[], @Nullable RangeQueryBuilder rangeQueryBuilder, @Nullable HighlightBuilder highlightBuilder, @Nullable AggregationBuilder aggregationBuilder) {
        SearchRequest searchRequest = new SearchRequest();
        searchRequest.indices(index);
        if (field == null && sortOrder == null) {
            if (rangeQueryBuilder != null) {
                if (aggregationBuilder != null) {
                    searchRequest.source(new SearchSourceBuilder().query(QueryBuilders.matchQuery(key, value)).from(from).size(size).fetchSource(includes, excludes).postFilter(rangeQueryBuilder).highlighter(highlightBuilder).aggregation(aggregationBuilder));
                } else {
                    searchRequest.source(new SearchSourceBuilder().query(QueryBuilders.matchQuery(key, value)).from(from).size(size).fetchSource(includes, excludes).postFilter(rangeQueryBuilder).highlighter(highlightBuilder));
                }

            } else {
                if (aggregationBuilder != null) {
                    searchRequest.source(new SearchSourceBuilder().query(QueryBuilders.matchQuery(key, value)).from(from).size(size).fetchSource(includes, excludes).highlighter(highlightBuilder).aggregation(aggregationBuilder));
                } else {
                    searchRequest.source(new SearchSourceBuilder().query(QueryBuilders.matchQuery(key, value)).from(from).size(size).fetchSource(includes, excludes).highlighter(highlightBuilder));
                }

            }
        } else {
            if (rangeQueryBuilder != null) {
                if (aggregationBuilder != null) {
                    searchRequest.source(new SearchSourceBuilder().query(QueryBuilders.matchQuery(key, value)).from(from).size(size).sort(field, sortOrder).fetchSource(includes, excludes).postFilter(rangeQueryBuilder).highlighter(highlightBuilder).aggregation(aggregationBuilder));
                } else {
                    searchRequest.source(new SearchSourceBuilder().query(QueryBuilders.matchQuery(key, value)).from(from).size(size).sort(field, sortOrder).fetchSource(includes, excludes).postFilter(rangeQueryBuilder).highlighter(highlightBuilder));
                }

            } else {
                if (aggregationBuilder != null) {
                    searchRequest.source(new SearchSourceBuilder().query(QueryBuilders.matchQuery(key, value)).from(from).size(size).sort(field, sortOrder).fetchSource(includes, excludes).highlighter(highlightBuilder).aggregation(aggregationBuilder));
                } else {
                    searchRequest.source(new SearchSourceBuilder().query(QueryBuilders.matchQuery(key, value)).from(from).size(size).sort(field, sortOrder).fetchSource(includes, excludes).highlighter(highlightBuilder));
                }

            }
        }
        try {
            return client().search(searchRequest, RequestOptions.DEFAULT);
        } catch (ElasticsearchStatusException | IOException e) {
            e.printStackTrace();
            return null;
        }
    }


    /**
     * 精确查询
     *
     * @param index 查询哪个index
     * @param key   查询数据的key
     * @param value 查询数据的value
     * @param from  数据展示起始位置
     * @param size  数据一次展示多少个数据
     * @return
     */
    public SearchResponse searchDocByResultExact(String index, String key, Object value, int from, int size, @Nullable String field, @Nullable SortOrder sortOrder, @Nullable String includes[], @Nullable String excludes[], @Nullable RangeQueryBuilder rangeQueryBuilder, @Nullable HighlightBuilder highlightBuilder, @Nullable AggregationBuilder aggregationBuilder) {
        SearchRequest searchRequest = new SearchRequest();
        searchRequest.indices(index);
        if (field == null && sortOrder == null) {
            if (rangeQueryBuilder != null) {
                if (aggregationBuilder != null) {
                    searchRequest.source(new SearchSourceBuilder().query(QueryBuilders.matchPhraseQuery(key, value)).from(from).size(size).fetchSource(includes, excludes).postFilter(rangeQueryBuilder).highlighter(highlightBuilder).aggregation(aggregationBuilder));
                } else {
                    searchRequest.source(new SearchSourceBuilder().query(QueryBuilders.matchPhraseQuery(key, value)).from(from).size(size).fetchSource(includes, excludes).postFilter(rangeQueryBuilder).highlighter(highlightBuilder));
                }

            } else {
                if (aggregationBuilder != null) {
                    searchRequest.source(new SearchSourceBuilder().query(QueryBuilders.matchPhraseQuery(key, value)).from(from).size(size).fetchSource(includes, excludes).highlighter(highlightBuilder).aggregation(aggregationBuilder));
                } else {
                    searchRequest.source(new SearchSourceBuilder().query(QueryBuilders.matchPhraseQuery(key, value)).from(from).size(size).fetchSource(includes, excludes).highlighter(highlightBuilder));
                }

            }
        } else {
            if (rangeQueryBuilder != null) {
                if (aggregationBuilder != null) {
                    searchRequest.source(new SearchSourceBuilder().query(QueryBuilders.matchPhraseQuery(key, value)).from(from).size(size).sort(field, sortOrder).fetchSource(includes, excludes).postFilter(rangeQueryBuilder).highlighter(highlightBuilder).aggregation(aggregationBuilder));
                } else {
                    searchRequest.source(new SearchSourceBuilder().query(QueryBuilders.matchPhraseQuery(key, value)).from(from).size(size).sort(field, sortOrder).fetchSource(includes, excludes).postFilter(rangeQueryBuilder).highlighter(highlightBuilder));
                }

            } else {
                if (aggregationBuilder != null) {
                    searchRequest.source(new SearchSourceBuilder().query(QueryBuilders.matchPhraseQuery(key, value)).from(from).size(size).sort(field, sortOrder).fetchSource(includes, excludes).highlighter(highlightBuilder).aggregation(aggregationBuilder));
                } else {
                    searchRequest.source(new SearchSourceBuilder().query(QueryBuilders.matchPhraseQuery(key, value)).from(from).size(size).sort(field, sortOrder).fetchSource(includes, excludes).highlighter(highlightBuilder));
                }

            }
        }
        try {
            return client().search(searchRequest, RequestOptions.DEFAULT);
        } catch (ElasticsearchStatusException | IOException e) {
            e.printStackTrace();
            return null;
        }
    }


    /**
     * 查询满足所有的条件的条件
     *
     * @param index
     * @param result
     * @param from
     * @param size
     * @param field
     * @param sortOrder
     * @param includes
     * @param excludes
     * @param isExact
     * @return
     */

    public SearchResponse searchDocByAndResult(String index, Map<String, Object> result, int from, int size, @Nullable String field, @Nullable SortOrder sortOrder, @Nullable String includes[], @Nullable String excludes[], Boolean isExact, @Nullable RangeQueryBuilder rangeQueryBuilder, @Nullable HighlightBuilder highlightBuilder, @Nullable AggregationBuilder aggregationBuilder) {
        SearchRequest searchRequest = new SearchRequest();
        searchRequest.indices(index);
        BoolQueryBuilder boolQueryBuilder = QueryBuilders.boolQuery();
        if (isExact) {
            result.forEach((key, value) -> {
                boolQueryBuilder.must(QueryBuilders.matchPhraseQuery(key, value));
            });
        } else {
            result.forEach((key, value) -> {
                boolQueryBuilder.must(QueryBuilders.matchQuery(key, value));
            });
        }
        if (rangeQueryBuilder != null) boolQueryBuilder.filter(rangeQueryBuilder);
        if (aggregationBuilder != null) {
            searchRequest.source(new SearchSourceBuilder().query(boolQueryBuilder).highlighter(highlightBuilder).aggregation(aggregationBuilder));
        } else {
            searchRequest.source(new SearchSourceBuilder().query(boolQueryBuilder).highlighter(highlightBuilder));
        }

        try {
            return client().search(searchRequest, RequestOptions.DEFAULT);
        } catch (ElasticsearchStatusException | IOException e) {
            e.printStackTrace();
            return null;
        }

    }

    /**
     * 查询不包含的数据
     *
     * @param index
     * @param result
     * @param from
     * @param size
     * @param field
     * @param sortOrder
     * @param includes
     * @param excludes
     * @param isExact
     * @return
     */


    public SearchResponse searchDocNotByAndResult(String index, Map<String, Object> result, int from, int size, @Nullable String field, @Nullable SortOrder sortOrder, @Nullable String includes[], @Nullable String excludes[], Boolean isExact, @Nullable RangeQueryBuilder rangeQueryBuilder, @Nullable HighlightBuilder highlightBuilder, @Nullable AggregationBuilder aggregationBuilder) {
        SearchRequest searchRequest = new SearchRequest();
        searchRequest.indices(index);
        BoolQueryBuilder boolQueryBuilder = QueryBuilders.boolQuery();
        if (isExact) {
            result.forEach((key, value) -> {
                boolQueryBuilder.mustNot(QueryBuilders.matchPhraseQuery(key, value));
            });
        } else {
            result.forEach((key, value) -> {
                boolQueryBuilder.mustNot(QueryBuilders.matchQuery(key, value));
            });
        }
        if (rangeQueryBuilder != null) boolQueryBuilder.filter(rangeQueryBuilder);
        if (aggregationBuilder != null) {
            searchRequest.source(new SearchSourceBuilder().query(boolQueryBuilder).highlighter(highlightBuilder).aggregation(aggregationBuilder));
        } else {
            searchRequest.source(new SearchSourceBuilder().query(boolQueryBuilder).highlighter(highlightBuilder));
        }
        try {
            return client().search(searchRequest, RequestOptions.DEFAULT);
        } catch (ElasticsearchStatusException | IOException e) {
            e.printStackTrace();
            return null;
        }
    }


    @Override
    public Long getItemCountByIndex(String index) {
        CountRequest countRequest = new CountRequest();
        countRequest.indices(index);
        try {
            return client().count(countRequest, RequestOptions.DEFAULT).getCount();
        } catch (ElasticsearchStatusException | IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * 查询一条或者多条满足的数据
     *
     * @param index
     * @param result
     * @param from
     * @param size
     * @param field
     * @param sortOrder
     * @param includes
     * @param excludes
     * @param isExact
     * @return
     */

    public SearchResponse searchDocByOrResult(String index, Map<String, Object> result, int from, int size, @Nullable String field, @Nullable SortOrder sortOrder, @Nullable String includes[], @Nullable String excludes[], Boolean isExact, @Nullable RangeQueryBuilder rangeQueryBuilder, @Nullable HighlightBuilder highlightBuilder, @Nullable AggregationBuilder aggregationBuilder) {
        SearchRequest searchRequest = new SearchRequest();
        searchRequest.indices(index);
        BoolQueryBuilder boolQueryBuilder = QueryBuilders.boolQuery();
        if (isExact) {
            result.forEach((key, value) -> {
                boolQueryBuilder.should(QueryBuilders.matchPhraseQuery(key, value));
            });
        } else {
            result.forEach((key, value) -> {
                boolQueryBuilder.should(QueryBuilders.matchQuery(key, value));
            });
        }
        if (rangeQueryBuilder != null) boolQueryBuilder.filter(rangeQueryBuilder);
        if (aggregationBuilder != null) {
            searchRequest.source(new SearchSourceBuilder().query(boolQueryBuilder).highlighter(highlightBuilder).aggregation(aggregationBuilder));
        } else {
            searchRequest.source(new SearchSourceBuilder().query(boolQueryBuilder).highlighter(highlightBuilder));
        }

        try {
            return client().search(searchRequest, RequestOptions.DEFAULT);
        } catch (ElasticsearchStatusException | IOException e) {
            e.printStackTrace();
            return null;
        }
    }


}
