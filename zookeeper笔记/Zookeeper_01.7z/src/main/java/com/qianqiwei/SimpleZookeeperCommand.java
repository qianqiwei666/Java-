package com.qianqiwei;

import lombok.extern.slf4j.Slf4j;
import org.apache.zookeeper.*;
import org.apache.zookeeper.data.ACL;
import org.apache.zookeeper.data.Stat;

import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;

/**
 * @author 钱琪炜
 * @version 1.3
 * @date 2022/4/21 17:21
 */

@Slf4j
public class SimpleZookeeperCommand extends ZookeeperCommand {


    public SimpleZookeeperCommand(ZookeeperBuilder zookeeperBuilder) {
        super(zookeeperBuilder);
    }

    @Override
    public boolean exits(String Node) {
        try {
            Stat exists = zooKeeper.exists(Node, false);
            if (exists != null) return true;
            return false;
        } catch (KeeperException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public byte[] getCurrentNode(String Node) {
        CountDownLatch countDownLatch = new CountDownLatch(1);
        byte value[][] = new byte[1][1];
        zooKeeper.getData(Node, false, new AsyncCallback.DataCallback() {
            @Override
            public void processResult(int rc, String path, Object ctx, byte[] data, Stat stat) {
                //查看当前节点是否存在
                if (stat != null) {
                    value[0] = data;
                } else {
                    log.info("当前节点不存在,数据获取失败!");
                    value[0] = null;
                }
                countDownLatch.countDown();
            }
        }, null);
        try {
            countDownLatch.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return value[0];
    }

    @Override
    public void WatchCurrentNode(String Node, Watcher watcher, AsyncCallback.DataCallback dataCallback) {
        if (!exits(Node)) {
            log.info("当前节点不存在!");
            return;
        }
        if (dataCallback == null) {
            try {
                zooKeeper.getData(Node, watcher, new Stat());
            } catch (KeeperException e) {
                e.printStackTrace();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        } else {
            zooKeeper.getData(Node, watcher, dataCallback, null);
        }
    }


    @Override
    public boolean setCurrentNode(String Node, byte[] value) {
        if (!exits(Node)) {
            log.info("当前节点不存在!");
            return false;
        }
        try {
            zooKeeper.setData(Node, value, getCurrentNodeByState(Node).getVersion());
            log.info("节点设置成功!");
            return true;
        } catch (KeeperException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return false;

    }


    @Override
    public boolean deleteCurrentNode(String Node) {
        //如果找不到就返回false
        if (!exits(Node)) {
            log.info("当前节点不存在!");
            return false;
        }
        try {
            zooKeeper.delete(Node, getCurrentNodeByState(Node).getVersion());
            log.info("成功删除节点!");
            return true;
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (KeeperException e) {
            e.printStackTrace();
        }
        return false;
    }


    @Override
    public void deleteCurrentNodeByAsync(String Node) {
        //如果找不到就返回false
        if (!exits(Node)) {
            log.info("当前节点不存在!");
            return;
        }
        zooKeeper.delete(Node, getCurrentNodeByState(Node).getVersion(), new AsyncCallback.VoidCallback() {
            @Override
            public void processResult(int rc, String path, Object ctx) {
                log.info(path + "节点删除成功!");
            }
        }, null);
    }


    @Override
    public String createNode(String Node, byte[] value, List<ACL> aclList, CreateMode createMode) {
        if (exits(Node)) {
            log.info("当前节点存在,创建失败!");
            return null;
        }
        try {
            String s = zooKeeper.create(Node, value, aclList, createMode);
            log.info("成功创建:" + Node);
            return s;
        } catch (KeeperException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public void createNodeByAsync(String Node, byte[] value, List<ACL> aclList, CreateMode createMode) {
        if (exits(Node)) {
            log.info("当前节点存在,创建失败!");
            return;
        }
        Stat stat = new Stat();
        zooKeeper.create(Node, value, aclList, createMode, new AsyncCallback.Create2Callback() {
            @Override
            public void processResult(int rc, String path, Object ctx, String name, Stat stat) {
                if (stat != null) log.info("异步创建" + value + "成功!");
            }
        }, stat);

    }

    @Override
    public Stat getCurrentNodeByState(String Node) {
        if (!exits(Node)) {
            log.info("不存在当前节点,节点信息获取失败!");
            return null;
        }
        Stat stat = new Stat();
        try {
            zooKeeper.getData(Node, false, stat);
            return stat;
        } catch (KeeperException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return null;

    }

    @Override
    public void shutdown() {
        try {
            zooKeeper.close();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<String> getCurrentByAllChild(String ParentNode, Watcher watcher) {
        if (!exits(ParentNode)) {
            log.info("不存在当前节点,获取失败!");
            return null;
        }
        try {
            List<String> children = null;
            if (watcher == null) children = zooKeeper.getChildren(ParentNode, false);
            else children = zooKeeper.getChildren(ParentNode, watcher);
            log.info("节点获取成功!");
            return children;
        } catch (KeeperException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return null;
    }


}
