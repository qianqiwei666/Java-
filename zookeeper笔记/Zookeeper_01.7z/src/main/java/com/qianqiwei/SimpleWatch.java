package com.qianqiwei;

import org.apache.zookeeper.AsyncCallback;
import org.apache.zookeeper.WatchedEvent;
import org.apache.zookeeper.Watcher;
import org.apache.zookeeper.ZooKeeper;
import org.apache.zookeeper.data.Stat;

/**
 * @author 钱琪炜
 * @version 1.0
 * @date 2022/4/21 23:32
 */


public class SimpleWatch implements Watcher {
    private ZooKeeper zooKeeper;
    private String Node;

    public SimpleWatch(ZooKeeper zooKeeper, String Node) {
        this.zooKeeper = zooKeeper;
        this.Node = Node;
    }

    //检测监测节点发生变化
    @Override
    public void process(WatchedEvent event) {
        zooKeeper.getData(Node, this, new AsyncCallback.DataCallback() {
            @Override
            public void processResult(int rc, String path, Object ctx, byte[] data, Stat stat) {
                System.out.println(path+":"+new String(data));
            }
        }, null);
    }
}
