package com.qianqiwei;

import lombok.extern.slf4j.Slf4j;
import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.WatchedEvent;
import org.apache.zookeeper.Watcher;
import org.apache.zookeeper.ZooDefs;

import java.util.Collections;
import java.util.List;
import java.util.concurrent.CountDownLatch;

/**
 * @author 钱琪炜
 * @version 1.7
 * @date 2022/4/22 9:46
 */


@Slf4j
public class DistributedLock {
    private ZookeeperCommand zookeeperCommand;
    private String ParentNode;
    private String ChildNode;


    /**
     * 需求:当创建节点的时候,创建的节点要去观察上一个节点的变化(删除),如果上一个节点不存在,自己就抢到锁
     * 如果中途有节点突然消失,可能某一个客户端挂掉了,就会去判断自己是否是最小的,如果是抢锁,如果不是,继续观察比自己小的(比如挂掉节点所观测的节点)
     */

    private DistributedLock() {

    }

    //创建锁
    public void Lock() throws Exception {
        zookeeperCommand.createNode(ParentNode, null, ZooDefs.Ids.OPEN_ACL_UNSAFE, CreateMode.PERSISTENT);
        //创建CountDownLatch等待异步执行
        CountDownLatch countDownLatch = new CountDownLatch(1);
        //创建新的节点(临时并且序列化的)
        String node = zookeeperCommand.createNode(ParentNode + ChildNode, null, ZooDefs.Ids.OPEN_ACL_UNSAFE, CreateMode.EPHEMERAL_SEQUENTIAL).replace(ParentNode + "/", "");
        //查找父节点下所有节点
        List<String> NodeList = zookeeperCommand.getCurrentByAllChild(ParentNode, null);
        Collections.sort(NodeList);
        //查看创建的节点是索引
        int index = NodeList.indexOf(node);
        //如果父节点下没有子节点,当前创建的节点就是第一个节点(第一个抢到锁)
        if (NodeList.size() == 0 || index == 0) return;
        if (index == -1) throw new Exception("节点构建错误!");
        //创建监听逻辑
        Watcher watcher = new Watcher() {
            @Override
            public void process(WatchedEvent event) {
                //如果发现前面的节点删除了
                if (event.getType() == Event.EventType.NodeDeleted) {
                    //如果发现自己不是最小的就继续监听
                    List<String> tempNodeList = zookeeperCommand.getCurrentByAllChild(ParentNode, null);
                    Collections.sort(tempNodeList);
                    int index = tempNodeList.indexOf(node);
                    if (index != 0)
                        log.info("当前节点:" + tempNodeList.get(index) + "监听节点:" + tempNodeList.get(index - 1) + "消失");
                    if (index != 0) {
                        log.info("当前不是最小的节点,继续监听" + ParentNode + "/" + tempNodeList.get(index - 1));
                        zookeeperCommand.WatchCurrentNode(ParentNode + "/" + tempNodeList.get(index - 1), this, (rc, path, ctx, data, stat) -> {
                        });
                    } else {
                        log.info("我是最小的节点,我在集合第" + tempNodeList.indexOf(node) + "位");
                        countDownLatch.countDown();
                    }

                }
            }
        };
        zookeeperCommand.WatchCurrentNode(ParentNode + "/" + NodeList.get(index - 1), watcher, null);
        countDownLatch.await();
    }

    //解锁
    public void unLock() throws Exception {
        //获取节点列表(锁列表)
        List<String> currentByAllChild = zookeeperCommand.getCurrentByAllChild(ParentNode, null);
        Collections.sort(currentByAllChild);
        if (currentByAllChild.size() == 0) throw new Exception("请上锁!");
        zookeeperCommand.deleteCurrentNode(ParentNode + "/" + currentByAllChild.get(0));
    }


    public static class DistributedLockBuilder {
        private DistributedLock distributedLock = new DistributedLock();


        public DistributedLockBuilder buildZookeeperCommand(ZookeeperCommand zookeeperCommand) {
            distributedLock.zookeeperCommand = zookeeperCommand;
            return this;
        }

        public DistributedLockBuilder buildNode(String ParentNode, String ChildNode) {
            distributedLock.ParentNode = ParentNode;
            distributedLock.ChildNode = ChildNode;
            return this;
        }

        public DistributedLock build() {
            return distributedLock;
        }


    }
}
