package com.qianqiwei;

import lombok.extern.slf4j.Slf4j;
import org.apache.zookeeper.Watcher;
import org.apache.zookeeper.ZooKeeper;

import java.io.IOException;
import java.util.concurrent.CountDownLatch;

/**
 * @author 钱琪炜
 * @version 1.0
 * @date 2022/4/21 14:23
 */

@Slf4j
public class SimpleZookeeperBuilder extends ZookeeperBuilder{
    @Override
    public ZookeeperBuilder buildAddress(String address) {
        this.address=address;
        return this;
    }

    @Override
    public ZookeeperBuilder buildTimeout(int timeout) {
        this.timeout=timeout;
        return this;
    }

    @Override
    public ZooKeeper build() {
        //watch是异步的。
        //为了保证链接成功,返回对象。
        CountDownLatch countDownLatch = new CountDownLatch(1);
        Watcher watcher = event -> {
            if (event.getState() == Watcher.Event.KeeperState.SyncConnected) {
                log.info("链接成功!");
                countDownLatch.countDown();
            }
        };
        try {
            ZooKeeper zooKeeper=new ZooKeeper(address,timeout,watcher);
            countDownLatch.await();
            return zooKeeper;
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
        return null;
    }
}
