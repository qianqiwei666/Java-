package com.qianqiwei;

import lombok.extern.slf4j.Slf4j;
import org.apache.zookeeper.AsyncCallback;
import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.Watcher;
import org.apache.zookeeper.ZooKeeper;
import org.apache.zookeeper.data.ACL;
import org.apache.zookeeper.data.Stat;

import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;


/**
 * @author 钱琪炜
 * @version 1.0
 * @date 2022/4/21 15:00
 */
@Slf4j
public abstract class ZookeeperCommand {
    protected ZooKeeper zooKeeper;
    private CountDownLatch detectConnection = new CountDownLatch(1);
    private CountDownLatch detectCreate = new CountDownLatch(1);

    public ZookeeperCommand(ZookeeperBuilder zookeeperBuilder) {
        //创建一个新的线程去链接Zookeeper
        new Thread(() -> {
            zooKeeper = zookeeperBuilder.build();
            try {
                //建立链接成功,主线程继续!
                detectCreate.countDown();
                //如果Zookeeper关闭了就结束当前线程!删除会话
                detect(zooKeeper);
                detectConnection.await();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }).start();
        try {
            detectCreate.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private void detect(ZooKeeper build) {
        while (true) {
            try {
                TimeUnit.SECONDS.sleep(1);
                if (build.getState() == ZooKeeper.States.CLOSED) {
                    log.info("会话结束!");
                    break;
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        detectConnection.countDown();
    }


    //查看当前节点是否存在
    public abstract boolean exits(String Node);

    //获取当前节点数据

    public abstract byte[] getCurrentNode(String Node);

    //获取当前节点动态数据

    public abstract void WatchCurrentNode(String Node, Watcher watcher, AsyncCallback.DataCallback dataCallback);

    //设置节点数据

    public abstract boolean setCurrentNode(String Node, byte[] value);

    //删除节点数据

    public abstract boolean deleteCurrentNode(String Node);

    //异步删除节点

    public abstract void deleteCurrentNodeByAsync(String Node);

    //创建节点
    public abstract String createNode(String Node, byte[] value, List<ACL> aclList, CreateMode createMode);

    //异步创建节点

    public abstract void createNodeByAsync(String Node, byte[] value, List<ACL> aclList, CreateMode createMode);

    //获取当前节点的状态信息
    public abstract Stat getCurrentNodeByState(String Node);

    //关闭zookeeper服务
    public abstract void shutdown();


    //查询当前节点子节点
    public abstract List<String> getCurrentByAllChild(String ParentNode,Watcher watcher);

}
