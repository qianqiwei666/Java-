package com.qianqiwei;

import lombok.extern.slf4j.Slf4j;
import org.apache.zookeeper.Watcher;
import org.apache.zookeeper.ZooKeeper;

import java.io.IOException;
import java.util.concurrent.CountDownLatch;


/**
 * @author 钱琪炜
 * @version 1.0
 * @date 2022/4/21 23:00
 */

public abstract class ZookeeperBuilder {
    protected String address;
    protected int timeout;

    public abstract ZookeeperBuilder buildAddress(String address);
    public abstract ZookeeperBuilder buildTimeout(int timeout) ;

    public abstract ZooKeeper build();
}
